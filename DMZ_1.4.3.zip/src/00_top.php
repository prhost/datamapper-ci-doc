LEAVE THIS GAP
<?php

/**
 * Data Mapper Class, OverZealous Edition
 *
 * Transforms database tables into objects.
 *
 * @license 	MIT License
 * @category	Models
 * @author  	Simon Stenhouse, Phil DeJarnett
 * @link    	http://www.overzealous.com/dmz/
 * @version 	1.4.2 ($Rev: 201 $) (Based on DataMapper 1.6.0)
 */

// --------------------------------------------------------------------------

/**
 * Data Mapper Class
 */
class DataMapper implements IteratorAggregate {
}