LEAVE THIS GAP
<?php

/**
 * Data Mapper Class, OverZealous Edition
 *
 * Transforms database tables into objects.
 *
 * @license 	MIT License
 * @category	Models
 * @author  	Simon Stenhouse, Phil DeJarnett
 * @link    	http://www.overzealous.com/dmz/
 * @version 	1.4.1 ($Rev: 193 $) (Based on DataMapper 1.6.0)
 */

// --------------------------------------------------------------------------

/**
 * Autoload
 *
 * Autoloads object classes that are used with DataMapper.
 */
spl_autoload_register('DataMapper::autoload');

// --------------------------------------------------------------------------

/**
 * Data Mapper Class
 */
class DataMapper {
}