<?php

	echo $bug->render_form($form_fields, $url);

?>