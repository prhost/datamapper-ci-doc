<div class="searchSection box">
<h3>Search</h3>
<?
	
	echo $bug->render_form($form_fields, $url, array('save_button' => 'Search', 'reset_button' => TRUE));

?>
</div>

<div class="searchResults">
<?

if( ! empty($bugs))
{
	$this->load->view('bugs/list', array('bugs' => $bugs));
}
?>
</div>

<span class="clear" />
