<p>Create an administrative account for yourself.</p>
<?
	
	echo $user->render_form(
	$form_fields,
	'admin/init/save');

?>