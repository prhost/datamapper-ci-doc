	<tr class="section">
		<th colspan="2"><?= $content ?></th>
	</tr>
