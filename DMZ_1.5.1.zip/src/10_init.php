<?php class DataMapper {
	/**
	 * Constructor
	 *
	 * Initialize DataMapper.
	 */
	function DataMapper($id = NULL)
	{
		$this->_assign_libraries();
	
		$this->_load_languages();

		$this->_load_helpers();

		$common_key = singular(get_class($this));
		
		// Determine model name
		if (empty($this->model))
		{
			$this->model = $common_key;
		}

		// Load stored config settings by reference
		foreach (array_keys(DataMapper::$config) as $key)
		{
			// Only if they're not already set
			if (empty($this->{$key}))
			{
				$this->{$key} =& DataMapper::$config[$key];
			}
		}

		// Load model settings if not in common storage
		if ( ! array_key_exists($common_key, DataMapper::$common))
		{
			// If model is 'datamapper' then this is the initial autoload by CodeIgniter
			if ($this->model == 'datamapper')
			{
				// Load config settings
				$this->config->load('datamapper', TRUE, TRUE);

				// Get and store config settings
				DataMapper::$config = $this->config->item('datamapper');
				
				DataMapper::_load_extensions(DataMapper::$global_extensions, DataMapper::$config['extensions']);
				unset(DataMapper::$config['extensions']);

				return;
			}
			
			$loaded_from_cache = FALSE;
			
			// Load in the production cache for this model, if it exists
			if( ! empty(DataMapper::$config['production_cache']))
			{
				// attempt to load the production cache file
				$cache_folder = APPPATH . DataMapper::$config['production_cache'];
				if(file_exists($cache_folder) && is_dir($cache_folder) && is_writeable($cache_folder))
				{
					$cache_file = $cache_folder . '/' . $common_key . EXT;
					if(file_exists($cache_file))
					{
						include($cache_file);
						if(isset($cache))
						{
							DataMapper::$common[$common_key] =& $cache;
							unset($cache);
			
							// allow subclasses to add initializations
							if(method_exists($this, 'post_model_init'))
							{
								$this->post_model_init(TRUE);
							}
							
							// Load extensions (they are not cacheable)
							$this->_initiate_local_extensions($common_key);
							
							$loaded_from_cache = TRUE;
						}
					}
				}
			}
			
			if(! $loaded_from_cache)
			{

				// Determine table name
				if (empty($this->table))
				{
					$this->table = plural(get_class($this));
				}
	
				// Add prefix to table
				$this->table = $this->prefix . $this->table;
	
				// Convert validation into associative array by field name
				$associative_validation = array();
	
				foreach ($this->validation as $name => $validation)
				{
					if(is_string($name)) {
						$validation['field'] = $name;
					} else {
						$name = $validation['field'];
					}
					
					// clean up possibly missing fields
					if( ! isset($validation['rules']))
					{
						$validation['rules'] = array();
					}
					if( ! isset($validation['label']))
					{
						$validation['label'] = $name;
					}
					// TODO: enable Localization of label
					
					// Populate associative validation array
					$associative_validation[$name] = $validation;
				}
				
				// set up id column, if not set
				if(!isset($associative_validation['id']))
				{
					$associative_validation['id'] = array(
						'field' => 'id',
						'label' => 'Identifier',
						'rules' => array('integer'),
						'get_rules' => array('intval')
					);
				}
	
				$this->validation = $associative_validation;
	
				// Get and store the table's field names and meta data
				$fields = $this->db->field_data($this->table);
	
				// Store only the field names and ensure validation list includes all fields
				foreach ($fields as $field)
				{
					// Populate fields array
					$this->fields[] = $field->name;
	
					// Add validation if current field has none
					if ( ! array_key_exists($field->name, $this->validation))
					{
						$this->validation[$field->name] = array('field' => $field->name, 'label' => '', 'rules' => array());
					}
				}
				
				// convert simple has_one and has_many arrays into more advanced ones
				foreach(array('has_one', 'has_many') as $arr)
				{
					$new = array();
					foreach ($this->{$arr} as $key => $value)
					{
						// allow for simple (old-style) associations
						if (is_int($key))
						{
							$key = $value;
						}
						// convert value into array if necessary
						if ( ! is_array($value))
						{
							$value = array('class' => $value);
						} else if ( ! isset($value['class']))
						{
							// if already an array, ensure that the class attribute is set
							$value['class'] = $key;
						}
						if( ! isset($value['other_field']))
						{
							// add this model as the model to use in queries if not set
							$value['other_field'] = $this->model;
						}
						if( ! isset($value['join_self_as']))
						{
							// add this model as the model to use in queries if not set
							$value['join_self_as'] = $value['other_field'];
						}
						if( ! isset($value['join_other_as']))
						{
							// add the key as the model to use in queries if not set
							$value['join_other_as'] = $key;
						}
						$new[$key] = $value;
					}
					// replace the old array
					$this->{$arr} = $new;
				}
				
				// allow subclasses to add initializations
				if(method_exists($this, 'post_model_init'))
				{
					$this->post_model_init(FALSE);
				}
	
				// Store common model settings
				foreach (array('table', 'fields', 'validation', 'has_one', 'has_many') as $item)
				{
					DataMapper::$common[$common_key][$item] = $this->{$item};
				}
				
				// if requested, store the item to the production cache
				if( ! empty(DataMapper::$config['production_cache']))
				{
					// attempt to load the production cache file
					$cache_folder = APPPATH . DataMapper::$config['production_cache'];
					if(file_exists($cache_folder) && is_dir($cache_folder) && is_writeable($cache_folder))
					{
						$cache_file = $cache_folder . '/' . $common_key . EXT;
						$cache = "<"."?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); \n";
						
						$cache .= '$cache = ' . var_export(DataMapper::$common[$common_key], TRUE) . ';';
				
						if ( ! $fp = @fopen($cache_file, 'w'))
						{
							show_error('Error creating production cache file: ' . $cache_file);
						}
						
						flock($fp, LOCK_EX);	
						fwrite($fp, $cache);
						flock($fp, LOCK_UN);
						fclose($fp);
					
						@chmod($cache_file, FILE_WRITE_MODE);
					}
				}
				
				// Load extensions last, so they aren't cached.
				$this->_initiate_local_extensions($common_key);
			}
		}

		// Load stored common model settings by reference
		foreach (array_keys(DataMapper::$common[$common_key]) as $key)
		{
			$this->{$key} =& DataMapper::$common[$common_key][$key];
		}

		// Clear object properties to set at default values
		$this->clear();
		
		if( ! empty($id) && is_numeric($id))
		{
			$this->get_by_id(intval($id));
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Autoload
	 *
	 * Autoloads object classes that are used with DataMapper.
	 *
	 * Note:
	 * It is important that they are autoloaded as loading them manually with
	 * CodeIgniter's loader class will cause DataMapper's __get and __set functions
	 * to not function.
	 *
	 * @access	public
	 * @param	string
	 * @return	void
	 */
	static function autoload($class)
	{
		// Don't attempt to autoload CI_ or MY_ prefixed classes
		if (in_array(substr($class, 0, 3), array('CI_', 'MY_')))
		{
			return;
		}

		// Prepare class
		$class = strtolower($class);

		// Prepare path
		$path = APPPATH . 'models';

		// Prepare file
		$file = $path . '/' . $class . EXT;

		// Check if file exists, require_once if it does
		if (file_exists($file))
		{
			require_once($file);
		}
		else
		{
			// Do a recursive search of the path for the class
			DataMapper::recursive_require_once($class, $path);
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Recursive Require Once
	 *
	 * Recursively searches the path for the class, require_once if found.
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @return	void
	 */
	static function recursive_require_once($class, $path)
	{
		if ($handle = opendir($path))
		{
			while (FALSE !== ($dir = readdir($handle)))
			{
				// If dir does not contain a dot
				if (strpos($dir, '.') === FALSE)
				{
					// Prepare recursive path
					$recursive_path = $path . '/' . $dir;

					// Prepare file
					$file = $recursive_path . '/' . $class . EXT;

					// Check if file exists, require_once if it does
					if (file_exists($file))
					{
						require_once($file);

						break;
					}
					else if (is_dir($recursive_path))
					{
						// Do a recursive search of the path for the class
						DataMapper::recursive_require_once($class, $recursive_path);
					}
				}
			}

			closedir($handle);
		}
	}
	
	// --------------------------------------------------------------------
	
	/**
	 * Loads in any extensions used by this class or globally.
	 * @return 
	 * @param object $extensions
	 * @param object $name
	 */
	static function _load_extensions(&$extensions, $names)
	{
		$CI =& get_instance();
		$class_prefixes = array(
			'DMZ_',
			'DataMapper_',
			'CI_',
			$CI->config->item('subclass_prefix')
		);
		foreach($names as $name => $options)
		{
			if( ! is_string($name))
			{
				$name = $options;
				$options = NULL;
			}
			// only load an extension if it wasn't already loaded in this context
			if(isset($extensions[$name]))
			{
				return;
			}
			
			if( ! isset($extensions['_methods']))
			{
				$extensions['_methods'] = array();
			}
			
			// determine the file name and class name
			if(strpos($name, '/') === FALSE)
			{
				$file = APPPATH . DataMapper::$config['extensions_path'] . '/' . $name . EXT;
				$ext = $name;
			}
			else
			{
				$file = APPPATH . $name . EXT;
				$ext = array_pop(explode('/', $name));
			}
			
			if(!file_exists($file))
			{
				show_error('DataMapper Error: loading extension ' . $name . ': File not found.');
			}
			
			// load class
			include_once($file);
			
			// Allow for DMZ_Extension, DataMapper_Extension, etc.
			foreach($class_prefixes as $prefix)
			{
				if(class_exists($prefix.$ext))
				{
					$ext = $prefix.$ext;
					break;
				}
			}
			if(!class_exists($ext))
			{
				show_error("DataMapper Error: Unable to find a class for extension $name.");
			}
			// create class
			if(is_null($options))
			{
				$o = new $ext();
			}
			else
			{
				$o = new $ext($options);
			}
			$extensions[$name] = $o;
			
			// figure out which methods can be called on this class.
			$methods = get_class_methods($ext);
			foreach($methods as $m)
			{
				// do not load private methods or methods already loaded.
				if($m[0] !== '_' &&
						is_callable(array($o, $m)) &&
						! array_key_exists($m, $extensions['_methods'])
						) {
					// store this method.
					$extensions['_methods'][$m] = $name;
				}
			}
		}
	}
	
	// --------------------------------------------------------------------
	
	function _initiate_local_extensions($common_key)
	{
		if(!empty($this->extensions))
		{
			$extensions = $this->extensions;
			$this->extensions = array();
			DataMapper::_load_extensions($this->extensions, $extensions);
		}
		else
		{
			// ensure an empty array
			$this->extensions = array('_methods' => array());
		}
		// bind to the shared key, for dynamic loading
		DataMapper::$common[$common_key]['extensions'] =& $this->extensions;
	}

	// --------------------------------------------------------------------
	
	/**
	 * Dynamically load an extension when needed.
	 * @param object $name Name of the extension (or array of extensions).
	 * @param array $options [optional] Options for the extension
	 * @param boolean $local [optional] If TRUE, only loads the extension into this object
	 * @return 
	 */
	function load_extension($name, $options = NULL, $local = FALSE)
	{
		if( ! is_array($name))
		{
			if( ! is_null($options))
			{
				$name = array($name => $options);
			}
			else
			{
				$name = array($name);
			}
		}
		// called individually to ensure that the array is modified directly
		// (and not copied instead)
		if($local)
		{
			DataMapper::_load_extensions($this->extensions, $name);
		}
		else
		{
			DataMapper::_load_extensions(DataMapper::$global_extensions, $name);
		}
		
	}

	// --------------------------------------------------------------------
	
}