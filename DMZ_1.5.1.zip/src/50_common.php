<?php class DataMapper {
	
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 *                                                                   *
	 * Common methods                                                    *
	 *                                                                   *
	 * The following are common methods used by other methods.           *
	 *                                                                   *
	 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


	// --------------------------------------------------------------------

	/**
	 * To Array
	 *
	 * Converts this objects current record into an array for database queries.
	 * If validate is TRUE (getting by objects properties) empty objects are ignored.
	 *
	 * @access	private
	 * @param	bool
	 * @return	array
	 */
	function _to_array($validate = FALSE)
	{
		$data = array();

		foreach ($this->fields as $field)
		{
			if ($validate && ! isset($this->{$field}))
			{
				continue;
			}
			
			$data[$field] = $this->{$field};
		}

		return $data;
	}

	// --------------------------------------------------------------------

	/**
	 * To Object
	 *
	 * Converts the query result into an array of objects.
	 *
	 * @access	private
	 * @param	array
	 * @param	string
	 * @return	array
	 */
	function _to_object($result, $model)
	{
		$items = array();

		foreach ($result as $row)
		{
			$item = new $model();

			// Populate this object with values from first record
			foreach ($row as $key => $value)
			{
				$item->{$key} = $value;
			}

			foreach ($this->fields as $field)
			{
				if (! isset($row->{$field}))
				{
					$item->{$field} = NULL;
				}
			}
			
			$item->_run_get_rules();

			$item->_refresh_stored_values();
			
			if($item->id)
			{
				// FIXME: remove this for version 2.0
				$items[$item->id] = $item;
			}
			else
			{
				$items[] = $item;
			}
		}

		return $items;
	}

	// --------------------------------------------------------------------

	/**
	 * Run Get Rules
	 *
	 * Processes values loaded from the database
	 *
	 * @access	public
	 * @param	mixed
	 * @return	object
	 */
	function _run_get_rules()
	{
		// Loop through each property to be validated
		foreach ($this->validation as $field => $validation)
		{
			// Get validation settings
			if(empty($validation['get_rules']))
			{
				continue;
			}
			$rules = $validation['get_rules'];
			// only process non-empty keys that are not specifically
			// set to be null
			if( ! isset($this->{$field}) && ! in_array('allow_null', $rules))
			{
				if(array_key_exists($field, $this->has_one))
				{
					// automatically process $item_id values
					$field = $field . '_id';
					if( ! isset($this->{$field}) && ! in_array('allow_null', $rules))
					{
						continue;
					}
				} else {
					continue;
				}
			}
			
			// Loop through each rule to validate this property against
			foreach ($rules as $rule => $param)
			{
				// Check for parameter
				if (is_numeric($rule))
				{
					$rule = $param;
					$param = '';
				}
				if($rule == 'allow_null')
				{
					continue;
				}

				if (method_exists($this, '_' . $rule))
				{
					// Run rule from DataMapper or the class extending DataMapper
					$result = $this->{'_' . $rule}($field, $param);
				}
				else if($this->_extension_method_exists('rule_' . $rule))
				{
					// Run an extension-based rule.
					$result = $this->{'rule_' . $rule}($field, $param);
				}
				else if (method_exists($this->form_validation, $rule))
				{
					// Run rule from CI Form Validation
					$result = $this->form_validation->{$rule}($this->{$field}, $param);
				}
				else if (function_exists($rule))
				{
					// Run rule from PHP
					$this->{$field} = $rule($this->{$field});
				}
			}
		}
		
		// Process all other has_one ITFKs
		foreach($this->has_one as $related => $rel_props)
		{
			$field = $related . '_id';
			if(isset($this->{$field}) && // If the field is set...
				( ! array_key_exists($field, $this->validation) || // And does not have a validation key or...
					! isset($this->validation[$field]['get_rules'])) &&  // a get_rules key...
				( ! array_key_exists($related, $this->validation) || // nor does the related have a validation key or...
					! isset($this->validation[$related]['get_rules'])) ) // a get_rules key
			{
				// assume an int
				if(is_numeric($this->{$field}))
				{
					$this->{$field} = intval($this->{$field});
				}
			} 
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Refresh Stored Values
	 *
	 * Refreshes the stored values with the current values.
	 *
	 * @access	private
	 * @return	void
	 */
	function _refresh_stored_values()
	{
		// Update stored values
		foreach ($this->fields as $field)
		{
			$this->stored->{$field} = $this->{$field};
		}

		// Check if there is a "matches" validation rule
		foreach ($this->validation as $field_name => $validation)
		{
			// If there is, match the field value with the other field value
			if (array_key_exists('matches', $validation['rules']))
			{
				$this->{$field_name} = $this->stored->{$field_name} = $this->{$validation['rules']['matches']};
			}
		}
	}
	
	// --------------------------------------------------------------------
	
	/**
	 * Query Backup
	 * Backs up the current query for this object 
	 * 
	 * @param object $restore [optional] If true, restores the backup, instead.
	 * @return void
	 */
	function _query_backup($restore = FALSE)
	{
		if($restore)
		{
			if( ! is_null($this->_query_backup_copy))
			{
				foreach($this->_query_backup_copy as $k => $f)
				{
					$this->db->{$k} = $f;
				}
				$this->_query_backup_copy = NULL;
			}
		}
		else
		{
			$this->_query_backup_copy = array();
			foreach($this->db as $k => $f)
			{
				if(strpos($k, 'ar_') === 0)
				{
					$this->_query_backup_copy[$k] = $f;
				}
			}
			// clear ActiveRecord
			$this->db->_reset_select();
			$this->db->_reset_write();
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Assign Libraries
	 *
	 * Assigns required CodeIgniter libraries to DataMapper.
	 *
	 * @access	private
	 * @return	void
	 */
	function _assign_libraries()
	{
		if ($CI =& get_instance())
		{
			$this->lang = $CI->lang;
			$this->load = $CI->load;
			$this->db = $CI->db;
			$this->config = $CI->config;
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Load Languages
	 *
	 * Loads required language files.
	 *
	 * @access	private
	 * @return	void
	 */
	function _load_languages()
	{

		// Load the DataMapper language file
		$this->lang->load('datamapper');
	}

	// --------------------------------------------------------------------

	/**
	 * Load Helpers
	 *
	 * Loads required CodeIgniter helpers.
	 *
	 * @access	private
	 * @return	void
	 */
	function _load_helpers()
	{
		// Load inflector helper for singular and plural functions
		$this->load->helper('inflector');

		// Load security helper for prepping functions
		$this->load->helper('security');
	}
}

// --------------------------------------------------------------------------

/**
 * Autoload
 *
 * Autoloads object classes that are used with DataMapper.
 * Must be at end due to implements IteratorAggregate...
 */
spl_autoload_register('DataMapper::autoload');

/* End of file datamapper.php */
/* Location: ./application/models/datamapper.php */
// leave this line