LEAVE THIS GAP
<?php

/**
 * Data Mapper Class, OverZealous Edition
 *
 * Transforms database tables into objects.
 *
 * @licence 	MIT Licence
 * @category	Models
 * @author  	Simon Stenhouse, Phil DeJarnett
 * @link    	http://www.overzealous.com/dmz/
 * @version 	1.3.2 (Based on DataMapper 1.6.0)
 */

// --------------------------------------------------------------------------

/**
 * Autoload
 *
 * Autoloads object classes that are used with DataMapper.
 */
spl_autoload_register('DataMapper::autoload');

// --------------------------------------------------------------------------

/**
 * Data Mapper Class
 */
class DataMapper {
}