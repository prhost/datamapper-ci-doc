<p class="users_setup"><a href="<?= site_url('users') ?>">Manage User Accounts</a><br/>
Add, edit, and delete users from this section.</p>

<?php

$this->load->view('admin/reset');

?>