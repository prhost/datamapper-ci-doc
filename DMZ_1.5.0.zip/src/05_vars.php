<? class DataMapper {
	
	static $config = array();
	static $common = array();
	static $global_extensions = array();

	var $error;
	var $stored;
	var $prefix = '';
	var $join_prefix = '';
	var $table = '';
	var $model = '';
	var $error_prefix = '';
	var $error_suffix = '';
	var $created_field = '';
	var $updated_field = '';
	var $auto_transaction = FALSE;
	var $auto_populate_has_many = FALSE;
	var $auto_populate_has_one = FALSE;
	var $valid = FALSE;
	var $validated = FALSE;
	var $local_time = FALSE;
	var $unix_timestamp = FALSE;
	var $fields = array();
	var $all = array();
	var $parent = array();
	var $validation = array();
	var $has_many = array();
	var $has_one = array();
	var $query_related = array();
	var $production_cache = FALSE;
	var $extensions_path = '';
	var $extensions = NULL;
	var $free_result_threshold = 100;
	var $default_order_by = NULL;
	
	// If true before a related get(), any extra fields on the join table will be added.
	var $_include_join_fields = FALSE;
	// If true before a save, this will force the next save to be new.
	var $_force_save_as_new = FALSE;
	// If true, the next where statement will not be prefixed with an AND or OR.
	var $_where_group_started = FALSE;
	// Used to backup and restore queries temporarily
	var $_query_backup_copy = NULL;

}