<? class DataMapper {
	
	static $config = array();
	static $common = array();
	static $global_extensions = array();

	var $error;
	var $stored;
	var $prefix = '';
	var $join_prefix = '';
	var $table = '';
	var $model = '';
	var $error_prefix = '';
	var $error_suffix = '';
	var $created_field = '';
	var $updated_field = '';
	var $auto_transaction = FALSE;
	var $auto_populate_has_many = FALSE;
	var $auto_populate_has_one = FALSE;
	var $valid = FALSE;
	var $validated = FALSE;
	var $local_time = FALSE;
	var $unix_timestamp = FALSE;
	var $fields = array();
	var $all = array();
	var $parent = array();
	var $validation = array();
	var $has_many = array();
	var $has_one = array();
	var $query_related = array();
	var $production_cache = FALSE;
	var $extensions_path = '';
	var $extensions = NULL;
	
	// If true before a related get(), any extra fields on the join table will be added.
	var $_include_join_fields = FALSE;

}